import { Component, OnInit } from '@angular/core';
import { Order } from '../../../order';
import { OrdersService } from '../../../orders.service';

@Component({
  selector: 'app-book-now',
  templateUrl: './book-now.component.html',
  styleUrls: ['./book-now.component.css'],
})
export class BookNowComponent implements OnInit {
  orders: any;
  order: Order;
  name: string;
  address: string;
  email: string;
  phone: string;
  pincode: string;
  constructor(private orderService: OrdersService) {}

  ngOnInit(): void {}

  bookOrders() {
    const newOrder = {
      name: this.name,
      email: this.email,
      address: this.address,
      phone: this.phone,
      pincode: this.pincode,
    };
    // console.log(newOrder);
    this.orderService.addOrder(newOrder).subscribe((order) => {
      console.log('booking successfull', order);
      this.orders.push(order);
      this.name = '';
      this.email = '';
      this.address = '';
      this.phone = '';
      this.pincode = '';
    });
  }
}
